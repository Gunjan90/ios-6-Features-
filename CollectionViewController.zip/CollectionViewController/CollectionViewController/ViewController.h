//
//  ViewController.h
//  CollectionViewController
//
//  Created by indianic on 18/07/12.
//  Copyright (c) 2012 indianic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
   
}

@end
